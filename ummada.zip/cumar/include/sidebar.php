


<div class="main-sidebar sidebar-style-2">
  <aside id="sidebar-wrapper">
    <div class="sidebar-brand">
      <a href="index.php"> <img alt="image" src="assets/img/lll.png" class="header-logo" /> <span
        class="logo-name">Library </span>
      </a>
    </div>



 
    <ul class="sidebar-menu" class="nav nav-tabs" id="main">
      <li class="menu-header">Main</li>
      <li class="dropdown active" class="nav-item">
        <a class="nav-link active" id="home-tab" data-toggle="tab" href="#dash" role="tab"
        aria-controls="home" aria-selected="true"><i data-feather="monitor"></i><span>Dashboard</span></a>
      </li>
      <li class="dropdown">
        <a href="#" class="menu-toggle nav-link has-dropdown"><i
          data-feather="briefcase"></i><span>Registration</span></a>
          <ul class="dropdown-menu" class="nav nav-tabs" id="main">
            <li class="nav-item"><a class="nav-link" id="home-tab" data-toggle="tab" href="#people" role="tab"
              aria-controls="home" aria-selected="true">people</a></li>
              <li class="nav-item"><a class="nav-link" id="home-tab" data-toggle="tab" href="#Ad" role="tab"
                aria-controls="home" aria-selected="true">Address</a></li>
                <li class="nav-item"><a class="nav-link" id="home-tab" data-toggle="tab" href="#Ac" role="tab"
                  aria-controls="home" aria-selected="true">Account</a></li>
                  <li class="nav-item"><a class="nav-link" id="home-tab" data-toggle="tab" href="#Au" role="tab"
                    aria-controls="home" aria-selected="true">Authors</a></li>
                    <li class="nav-item"><a class="nav-link" id="home-tab" data-toggle="tab" href="#cat" role="tab"
                      aria-controls="home" aria-selected="true">Category</a></li>
                      <li class="nav-item"><a class="nav-link" id="home-tab" data-toggle="tab" href="#book" role="tab"
                        aria-controls="home" aria-selected="true">Books</a></li>
                        <li class="nav-item"><a class="nav-link" id="home-tab" data-toggle="tab" href="#am" role="tab"
                          aria-controls="home" aria-selected="true">Amaah</a></li>
                        </ul>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="command"></i><span>Charges</span></a>
                        <ul class="dropdown-menu" class="nav nav-tabs" id="main">
                          <li class="nav-item"><a class="nav-link" id="home-tab" data-toggle="tab" href="#Ex" role="tab"
                            aria-controls="home" aria-selected="true">Expences</a></li>
                            
                              <li class="nav-item"><a class="nav-link" id="home-tab" data-toggle="tab" href="#ch" role="tab"
                                aria-controls="home" aria-selected="true">charge</a></li>
                                <li class="nav-item"><a class="nav-link" id="home-tab" data-toggle="tab" href="#ex" role="tab"
                                aria-controls="home" aria-selected="true">expence_charge</a></li>
                                
                              </ul>
                            </li>
                            <li class="dropdown">
                              <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="credit-card"></i><span>Payments</span></a>
                              <ul class="dropdown-menu" class="nav nav-tabs" id="main">
                                <li class="nav-item"><a class="nav-link" id="home-tab" data-toggle="tab" href="#pur" role="tab"
                                  aria-controls="home" aria-selected="true">purchase</a></li>
                                  <li class="nav-item"><a class="nav-link" id="home-tab" data-toggle="tab" href="#pr" role="tab"
                                    aria-controls="home" aria-selected="true">purchase_return</a></li>
                                    <li class="nav-item"><li class="nav-item"><a class="nav-link" id="home-tab" data-toggle="tab" href="#py" role="tab"
                                      aria-controls="home" aria-selected="true">payments</a></li></li>
                                    </ul>
                                  </li>
                                  <li class="dropdown">
                                    <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="dollar-sign"></i><span>Receipts</span></a>
                                    <ul class="dropdown-menu" class="nav nav-tabs" id="main">
                                      <li class="nav-item"><a class="nav-link" id="home-tab" data-toggle="tab" href="#r" role="tab"
                                        aria-controls="home" aria-selected="true">Receipts</a></li>

                                      </ul>
                                    </li>
                                    <li class="dropdown">
                                      <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="user-plus"></i><span>Users</span></a>
                                      <ul class="dropdown-menu" class="nav nav-tabs" id="main">

                                        <li class="nav-item"><a class="nav-link" id="home-tab" data-toggle="tab" href="#user" role="tab"
                                          aria-controls="home" aria-selected="true">All-Users</a></li>
                                          
                                        </ul>
                                      </li>
                                      <li class="dropdown">
                                        <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="file-text"></i><span>Reports</span></a>
                                        <ul class="dropdown-menu" class="nav nav-tabs" id="main">

                                          <li class="nav-item"><a class="nav-link" id="home-tab" data-toggle="tab" href="#all" role="tab"
                                            aria-controls="home" aria-selected="true">All-Books</a></li>
                                            <li class="nav-item"><a class="nav-link" id="home-tab" data-toggle="tab" href="#ar" role="tab"
                                              aria-controls="home" aria-selected="true">Amaah-Books</a></li>
                                              <li class="nav-item"><a class="nav-link" id="home-tab" data-toggle="tab" href="#in" role="tab"
                                                aria-controls="home" aria-selected="true">All-Book-Information</a></li>

                                                <li class="nav-item"><a class="nav-link" id="home-tab" data-toggle="tab" href="#net" role="tab"
                                                  aria-controls="home" aria-selected="true">Net-Income</a></li>
                                                </ul>
                                              </li>
                                            </ul>





                                          </aside>
                                        </div>



